/* 
les informations relatives au passager n°916 : son nom, son âge, sa classe, sa ou ses cabines, le nom du port 
où il a embarqué, numéro et catégorie de l'embarcation de sauvetage qui l'a éventuellement secouru
*/

SELECT Name, Age, PClass, CabinCode, PortName, L LifeBoatId, LifeBoatCat
FROM PASSENGER P,OCCUPATION O,LIFEBOAT L,PORT PO,RESCUE R
WHERE P.PortId = PO.PortId 
AND P.PassengerId = O.PassengerId 
AND R.PassengerId = P.PassengerId 
AND R.LifeBoatId = L.LifeBoatId 
AND P.PassengerId = 916;


/* 
si le nom et le rôle des domestiques du passager n°1264 est exact 
*/

SELECT Name,Role
FROM PASSENGER P, SERVICE S
WHERE P.PassengerId=S.PassengerId_Dom AND PassengerId_Emp=1264;

/* 
si la liste des passagers ayant été secourus par le canot n°7 est exacte 
*/

SELECT P PassengerId, Name
FROM PASSENGER P,RESCUE R
WHERE LifeBoatId='7' AND P.PassengerId=R.PassengerId;






    
