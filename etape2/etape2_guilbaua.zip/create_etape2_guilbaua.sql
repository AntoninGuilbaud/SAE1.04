CREATE TABLE PORT(
    PortId char(1) primary key CHECK (PortId in ('C', 'Q', 'S')),
    PortName varchar not null,
    Country varchar not null
);

CREATE TABLE PASSENGER(
    PassengerId int primary key,
    Name varchar not null,
    Sex varchar,
    Age int,
    Survived int CHECK (Survived in (0, 1)),
    PClass int not null CHECK (PClass in (1, 2, 3)),
    PortId char(1) CHECK (PortId in ('C', 'Q', 'S')) REFERENCES PORT(PortId)
);

CREATE TABLE OCCUPATION(
    PassengerId int REFERENCES PASSENGER(PassengerId),
    CabinCode varchar,
    primary key (PassengerId, CabinCode)
);

CREATE TABLE SERVICE(
    PassengerId_Dom int primary key REFERENCES PASSENGER(PassengerId),
    PassengerId_Emp int not null REFERENCES PASSENGER(PassengerId),
    Role varchar not null
);

CREATE TABLE CATEGORY(
    LifeBoatCat varchar primary key CHECK (LifeBoatCat in ('standard', 'secours','radeau')),
    Structure varchar not null CHECK (Structure in ('bois', 'bois et toile')),
    Places int not null
);

CREATE TABLE LIFEBOAT(
    LifeBoatId varchar primary key,
    LifeBoatCat varchar REFERENCES CATEGORY(LifeBoatCat),
    Side varchar not null CHECK (Side in ('babord', 'tribord')),
    Position varchar not null CHECK (Position in ('avant', 'arriere')),
    Location varchar not null DEFAULT 'pont',
    Lauching_Time Time not null
);

CREATE TABLE RECOVERY(
    LifeBoatId varchar REFERENCES LIFEBOAT(LifeBoatId),
    Recovery_Time Time not null
);

CREATE TABLE RESCUE(
    PassengerId int REFERENCES PASSENGER(PassengerId),
    LifeBoatId varchar not null REFERENCES LIFEBOAT(LifeBoatId)
);