INSERT INTO Port 
VALUES ('H', 'Lyon', 'France');

/* 
ERROR:  new row for relation "port" violates check constraint "port_portid_check"
DETAIL:  Failing row contains (H, Lyon, France).

Commentaire: L'attribut PortId doit être C, Q ou S. Il doit également être qu'un seul caractère.
*/

INSERT INTO Port(PortId)
VALUES ('C');

/* 
ERROR:  null value in column "portname" of relation "port" violates not-null constraint
DETAIL:  Failing row contains (C, null, null).

Commentaire: L'attribut PortName et Country ne peuvent pas être null.
*/

/* Commentaire : Nous avons vérifié pour PortId, nous le referons plus */

INSERT INTO PASSENGER
VALUES ('test', 3, 4, 'testage', 2, 4, 'C');

/* 
ERROR:  invalid input syntax for type integer: "test"
LINE 2: VALUES ('test', 3, 4, 'testage', 2, 4, 'Z');

Commentaire: Type integer attendu pour PassengerId.
*/

INSERT INTO PASSENGER
VALUES (1222, 3, 4, 'testage', 2, 4, 'C');

/* 
ERROR:  invalid input syntax for type integer: "testage"
LINE 2: VALUES (1222, 3, 4, 'testage', 2, 4, 'Z');

Commentaire: Pour les attribut Name et Sex, type varchar attendu mais varchar accepte les chiffres.
donc pas d'erreur.
*/

INSERT INTO PASSENGER
VALUES (1222, 'Passager 1', 'Homme', 18, 2, 4, 'C');

/* 
ERROR:  new row for relation "passenger" violates check constraint "passenger_pclass_check"
DETAIL:  Failing row contains (1222, Passager 1, Homme, 18, 2, 4, Z).

Commentaire: L'attribut PClass doit être soit 1, 2 ou 3.
*/

INSERT INTO PASSENGER
VALUES (1222, 'Passager 1', 'Homme', 18, 2, 2, 'C');

/*
ERROR:  new row for relation "passenger" violates check constraint "passenger_survived_check"
DETAIL:  Failing row contains (1222, Passager 1, Homme, 18, 2, 2, C).

Commentaire: L'attribut Survived doit être 0 ou 1.
*/


/* Commentaire : Il faut aussi prendre en compte que les attributs PortId, Age, Survived et Pclass doivent être des integer */

INSERT INTO OCCUPATION
VALUES ('testocc', 'testcabin');

/*
ERROR:  invalid input syntax for type integer: "testocc"
LINE 2: VALUES ('testocc', 'testcabin');

Commentaire: L'attribut PassengerId ne peut pas être du caractère mais doit être un integer.
*/

INSERT INTO SERVICE
VALUES (18);

/*
ERROR:  null value in column "passengerid_emp" of relation "service" violates not-null constraint
DETAIL:  Failing row contains (18, null, null).

Commentaire: L'attribut PassengerId_Emp et Role doivent être renseignés. De plus, les attributs
PassengerId_Dom et PassengerId_Emp doivent être des integer.
*/

INSERT INTO CATEGORY
VALUES ('testcat', 'metal', 18);

/*
ERROR:  new row for relation "category" violates check constraint "category_lifeboatcat_check"
DETAIL:  Failing row contains (testcat, metal, 18).

Commentaire: L'attribut LifeBoatCat doit être soit 'standard', soit 'secours' ou  soit'radeau'.
*/

INSERT INTO CATEGORY
VALUES ('standard', 'metal', 18);

/*
ERROR:  new row for relation "category" violates check constraint "category_structure_check"
DETAIL:  Failing row contains (standard, metal, 18).

Commentaire: L'attribut Structure doit être soit 'bois' ou soit 'bois et toile'. De plus, Places
et Structure doivent être renseignés.
*/

/* Commentaire : LifeBoat Cat etant deja vérifié, nous ne le referons plus */

INSERT INTO LIFEBOAT
VALUES ('testboat', 'standard', 'testside', 'testposition', 'testlocation', 'testheure');

/*
ERROR:  invalid input syntax for type time: "testheure"
LINE 2: ...ard', 'testside', 'testposition', 'testlocation', 'testheure...

Commentaire: L'attribut Lauching_Time doit être de type Time.
*/


INSERT INTO LIFEBOAT
VALUES ('testboat', 'standard', 'testside', 'testposition', 'testlocation', '18:00:00');

/*
ERROR:  new row for relation "lifeboat" violates check constraint "lifeboat_position_check"
DETAIL:  Failing row contains (testboat, standard, testside, testposition, testlocation, 18:00:00).

Commentaire: L'attribut Position doit être soit 'avant' ou soit 'arriere'.
*/


INSERT INTO LIFEBOAT
VALUES ('testboat', 'standard', 'testside', 'avant', 'testlocation', '18:00:00');

/*
ERROR:  new row for relation "lifeboat" violates check constraint "lifeboat_side_check"
DETAIL:  Failing row contains (testboat, standard, testside, avant, testlocation, 18:00:00).

Commentaire: L'attribut Side doit être soit 'babord' ou soit 'tribord'.
*/

/* Commentaire : De plus, les attributs Side, Position, Location, et lauchingtime doivent être
renseignés */


INSERT INTO RECOVERY
VALUES ('testboat', null);

/*
ERROR:  null value in column "recovery_time" of relation "recovery" violates not-null constraint
DETAIL:  Failing row contains (testboat, null).

Commentaire: L'attribut Recovery_Time doit être renseigné et de type Time.
*/

INSERT INTO RESCUE
VALUES ('Passanger 1', null);

/*
ERROR:  invalid input syntax for type integer: "Passanger 1"
LINE 2: VALUES ('Passanger 1', null);

Commentaire: L'attribut PassengerId doit être un integer. 
*/

INSERT INTO RESCUE
VALUES (188, null);

/*
ERROR:  null value in column "lifeboatid" of relation "rescue" violates not-null constraint
DETAIL:  Failing row contains (188, null).

Commentaire: L'attribut LifeBoatId doit être renseigné.
*/

